#include <crt.hpp>

extern "C" void __chkstk(size_t size) {
    // return crt::chkstk();
}
