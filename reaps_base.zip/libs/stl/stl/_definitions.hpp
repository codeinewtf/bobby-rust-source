#pragma once
// @note: @es3n1n: predefined vvvvv
#if defined(_HAS_STATIC_RTTI)
    #undef _HAS_STATIC_RTTI
#endif

#if defined(_HAS_EXCEPTIONS)
    #undef _HAS_EXCEPTIONS
#endif

#if defined(_HAS_ITERATOR_DEBUGGING)
    #undef _HAS_ITERATOR_DEBUGGING
#endif

#if defined(_THROW)
    #undef _THROW
#endif

#if defined(_RAISE)
    #undef _RAISE
#endif

#if defined(_CPPRTTI)
    #undef _CPPRTTI
#endif

#define _HAS_STATIC_RTTI 0
#define _HAS_EXCEPTIONS 0
#define _HAS_ITERATOR_DEBUGGING 0

#define _THROW(x) void(0)
#define _RAISE(x) void(0)
// @note: @es3n1n: predefined ^^^^^

// @note: @es3n1n: warnings vvvvv
#if defined(__clang__) || defined(__GNUC__)
    #pragma clang diagnostic ignored "-Wformat-security"
#endif
// @note: @es3n1n: warnings ^^^^^

// @note: @es3n1n: custom vvvvv
#define _DO_RAISE 0
// @note: @es3n1n: custom ^^^^^
